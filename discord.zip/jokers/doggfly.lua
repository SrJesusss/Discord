SMODS.Joker{ --Dogg.fly
    key = "doggfly",
    config = {
        extra = {
            levels = 1
        }
    },
    loc_txt = {
        ['name'] = 'Dogg.fly',
        ['text'] = {
            [1] = 'If the hand played contains {C:attention}Flush{} and a',
            [2] = 'card with {C:attention}4{} rank level up',
            [3] = 'the current poker hand played'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 7,
        y = 2
    },
    display_size = {
        w = 71 * 0.95, 
        h = 95 * 0.25
    },
    cost = 5,
    rarity = "discord_message",
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["discord_dm_me"] = true },

    
    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play  then
            if (next(context.poker_hands["Flush"]) and context.other_card:get_id() == 4 and (function()
                for i = 1, #context.scoring_hand do
                    local scoring_card = context.scoring_hand[i]
                    if scoring_card:get_id() == 4 then
                        return scoring_card == context.other_card
                        end
                    end
                    return false
                    end)()) then
                        local target_hand = (context.scoring_name or "High Card")
                        return {
                            level_up = card.ability.extra.levels,
                            level_up_hand = target_hand,
                            message = localize('k_level_up_ex')
                        }
                    end
                end
            end
}